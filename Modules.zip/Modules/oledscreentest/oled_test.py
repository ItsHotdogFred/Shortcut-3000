from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import time
import network

SSID = "GallagherWifi"
PASSWORD = "Wahanui101"

wlan = network.WLAN(network.STA_IF)  # STA_IF = "station" mode, i.e. act as a client
wlan.active(True)                     # power on the WiFi radio

i2c = I2C(0, scl=Pin(35), sda=Pin(33), freq=400000)

BUTTON_PIN = 12  # change to whichever GPIO you wired the button to
button = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)
button2 = Pin(11, Pin.IN, Pin.PULL_UP)

oled = SSD1306_I2C(128, 32, i2c)

oled.fill(0)
oled.text("It works!", 4, 6)
oled.text("SSD1306 OLED", 4, 18)
oled.rect(0, 0, 128, 32, 1)
oled.show()

print("Sent test pattern to display. Check the screen.")

pos = 4

while True:
    oled.fill(0)
    oled.text("It works!", 4, 6)
    # oled.text("SSD1306 OLED", pos, 18)
    oled.text(str(pos), 4, 18)
    oled.rect(0, 0, 128, 32, 1)
    oled.show()
    if button.value() == 0:
        pos += 1
    if button2.value() == 0:
        pos -= 1
    time.sleep(0.05)
