from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import time
import network
import urequests as requests

url = "https://api.open-meteo.com/v1/forecast?latitude=-36.85&longitude=174.76&current=temperature_2m"

SSID = "GallagherWifi"
PASSWORD = "Wahanui101"

i2c = I2C(0, scl=Pin(35), sda=Pin(33), freq=400000)

oled = SSD1306_I2C(128, 32, i2c)

wlan = network.WLAN(network.STA_IF)  # STA_IF = "station" mode, i.e. act as a client
wlan.active(True)                     # power on the WiFi radio

if not wlan.isconnected():
    print("Connecting to {}...".format(SSID))
    wlan.connect(SSID, PASSWORD)

    timeout = 10  # seconds
    start = time.time()
    while not wlan.isconnected():
        if time.time() - start > timeout:
            print("Failed to connect (timed out)")
            raise SystemExit
        time.sleep(0.5)

print("Connected!")
print("IP address:", wlan.ifconfig()[0])

response = requests.get(url)
data = response.json()
response.close()
current_temp = data["current"]["temperature_2m"]
print(f"Current temperature in Auckland: {current_temp}°C")

oled.fill(0)
oled.text(wlan.ifconfig()[0], 4, 6)
oled.text(str(current_temp), 4, 24)
oled.show()
