from machine import Pin, I2C

i2c = I2C(0, scl=Pin(35), sda=Pin(33), freq=400000)

print("Scanning I2C bus...")
devices = i2c.scan()

if not devices:
    print("No I2C devices found. Check wiring (SDA/SCK swapped? loose GND?).")
else:
    print("Found {} device(s):".format(len(devices)))
    for addr in devices:
        print(" - 0x{:02X}".format(addr))
