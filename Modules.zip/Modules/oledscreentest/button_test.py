from machine import Pin
import time

BUTTON_PIN = 12  # change to whichever GPIO you wired the button to

button = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)

print("Watching button... press it (Ctrl-C to stop)")

last_state = 1
while True:
    state = button.value()
    if state != last_state:
        if state == 0:
            print("Pressed!")
        else:
            print("Released")
        last_state = state
    time.sleep(0.02)
